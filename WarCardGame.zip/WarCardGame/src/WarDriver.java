
public class WarDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deck deck = new Deck();
		Card[] cards = deck.getCards();
		//deck.print();
		deck.shuffle();
		deck.print();
		Deck mine = deck.subDeck(26, 51);
		mine.print();
		
		
	}
	public static int binarySearch(Card[] cards, Card target)
	{
		int low = 0;
		int high = cards.length - 1;
		while(low <= high)
		{
			System.out.println(low + ", " + high);
			int mid = (low + high)/ 2;
			int comp = cards[mid].compareTo(target);
			if(comp == 0) return mid;
			else if (comp < 0)low = mid + 1;
			else high = mid -1;
		}
		return -1;
	}
	public static int search(Card[] cards, Card target)
	{
		for(int i = 0; i < cards.length; i++)
		{
			System.out.println(cards[i]);
			if(cards[i].equals(target)) {
				return i;
			}
		}
		return -1;
	}
	public static void printDeck(Card[] cards)
	{
		if(cards[0] == null) System.out.println("No cards yet!");
		
		for(Card card : cards)
		{
			System.out.println(card);
		}
	}
}
